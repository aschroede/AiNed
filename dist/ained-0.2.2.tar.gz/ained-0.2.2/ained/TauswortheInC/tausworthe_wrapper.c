# include <stdint.h>


uint32_t tausworthe(void);

uint32_t tausworthe_wrapper() {
    return tausworthe();
}
